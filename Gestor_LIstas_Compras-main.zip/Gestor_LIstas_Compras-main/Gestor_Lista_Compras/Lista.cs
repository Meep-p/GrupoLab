﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestor_Lista_Compras
{
    internal class Lista
    {
        public string nomeLista { get; set; }


        public void alterarLista() { }

        public void removerList()
        { nomeLista = null; }

    }
}
